/*
 *Elaborar un algoritmo que lea el radio(r) de una esfera, calcule e imprima el volumen y el área
 */
package ejercicio13;
import java.util. Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);
        // Declaracion de variables
        double radio,volumen,area,volumenF;
        // Solicitud de ingreso de datos
        System.out.println("Ingrese el valor del radio: ");
        radio=entrada.nextInt();
        // Calculo de datos
        area=3.146*(radio*radio);
        volumen= (4*3.146)*(radio*radio*radio);
        volumenF= volumen/3;
        System.out.println("El area de la esfera es de "+area);
        System.out.println("El volumen de la esfera es de "+volumenF);
        
        
        
        
    }
    
}
