/*
 La velocidad de la luz es de 300 000 kilómetros por segundos. Elabore un algoritmo que lea un tiempo en 
 segundos e imprima la distancia que recorre en dicho tiempo.
 */
package ejercicio5;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada =new Scanner(System.in);
        // Declaracion de variables
      int  velocidaLuz =300000,seg,dis;
      // Solicitud de ingreso de datos
      System.out.println("Ingrese la cantidad de segundo");
      seg= entrada.nextInt();
      //calculo de valor
      dis= velocidaLuz*seg;
      //Muestra de datos de pantalla
      System.out.println("La distancia recorrida en el tiempo  " +seg+ " segundo(s) a la velocidad de la luz "+dis);
      
      
    }
    
}
