/*
Elaborar un algoritmo que lea la cantidad de dolares que se va a comprar y el timpo de cambio 
( costo de un dolar) en: yenes pesetas,libars esterlinas y marcos.Calcular e imprimir la cantidad que se debe
pagar en yenes, pesetas,libras esterlinas y marcos.
*/
package ejercicio15;
import java.util. Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada= new Scanner (System.in);
        //Declaracion de variables
        double dolar,yenes=108.51,pesetas=156.79,lbsE=0.79752,marcos=1.84;
        double yenesF, pesetasF,lbsEF,marcosF;
        //Solicitud deingreso de datos
        System.out.println("Ingrese la cantidad de dolares: ");
        dolar=entrada.nextDouble();
        //Calculo
        yenesF=dolar*yenes;
        pesetasF=dolar*pesetas;
        lbsEF = dolar* lbsE;
        marcosF= dolar*marcos;
        System.out.println("La cantidad de dolares en yenes es  de. "+yenesF);
        System.out.println("La cantida de dolares en pesetas es de: "+pesetasF);
        System.out.println("La cantidad de dolares en libras esterlinas "+lbsEF);
        System.out.println("La cantidad de dolares en marcos es de: "+marcos);
        
        
    }
}
