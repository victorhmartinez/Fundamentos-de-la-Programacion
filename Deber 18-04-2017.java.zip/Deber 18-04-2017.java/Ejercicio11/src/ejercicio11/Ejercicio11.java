/*
Elabore un algoritmo que lea la cantidad de dólares a comprar y el tipo de cambio a pesos 
(costo de un dólar en pesos);calcular e imprimir la cantidad a pagar en pesos por la cantidad de dólares 
indicado.
 */
package ejercicio11;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner entrada= new Scanner(System.in);
      //Declaracion de variables
      int cant ;
      double pes = 18.51,dolares ;
      //Solicitud de ingreso de variables
      System.out.println("Ingrese la cantidad de dolares: ");
      cant=entrada.nextInt();
      System.out.println("El precio del peso es: "+pes);
      // Calculos
      dolares=(cant*pes);
      System.out.println("La cantidad a pagar en pesos por la cantidad de dolares inidicada es de: "+dolares);
              
    }
    
}
