/*
 Elabore un algoritmo que lea una temperatura en grados centígrados y obtenga e imprima la temperatura 
 Fahrenheit equivalente
 */
package ejercicios7;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicios7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        //declacrion de variables
        double fah,cel;
        // Solicitud de ingreso de datos
        System.out.println("Ingrese la cantidad de grados en  Celsius ");
        cel=entrada.nextInt();
        // Realizacion de calculos
        fah=(1.8*cel)+32;
            
        System.out.println("La temperatura ingresada "+cel+" celsius en fahrenheit "+fah);
        
        
    }
    
}
