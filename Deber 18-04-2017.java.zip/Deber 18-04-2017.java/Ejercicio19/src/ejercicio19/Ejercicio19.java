/*
 Elaborar un algoritmo que permita leer el tamaño de un ángulo en grados e
imprima el seno y coseno. Debe convertirse los grados leídos a radianes antes de
hacer los calculos.
 */
package ejercicio19;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);
        // Declaracion de variables
        double grados,rad, cos, sen;
        System.out.println("Ingrese el tamaño del angulo en grados");
        grados=entrada.nextDouble();
        // Calculos
        rad=(grados*3.146)/180;
        cos=Math.cos(grados);
        sen=Math.sin(grados);
        System.out.println("El valor del seno es: "+sen+"\nEl  valor del coseno es: "+cos);
        
        
        
    }
    
}
