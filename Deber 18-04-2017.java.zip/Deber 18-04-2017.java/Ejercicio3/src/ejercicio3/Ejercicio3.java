/*
Elaborar un algoritmo que lea una cantidad de horas e imprima su equivalente en minutos, segundos y días.
 */
package ejercicio3;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
// Declaracion de variables
int nHoras, min,segun;
double dias;
//Solicitud de ingrese de datos por parte del usuario
System.out.println ("Ingrese el numero de horas que desea transformar");
nHoras=entrada.nextInt();
//calculo
min=nHoras*60;
segun= nHoras*3600;
dias= nHoras*0.0416667;
// muestra de  datos en pantalla
System.out.println("La tranformacion de horas  en minutos da "+min+ " minutos " );
System.out.println("La transformacion de horas en segundos da "+segun+" segundos");
System.out.println("La transformacion de horas en dias da "+dias+ " dias");
        
    }
    
}
