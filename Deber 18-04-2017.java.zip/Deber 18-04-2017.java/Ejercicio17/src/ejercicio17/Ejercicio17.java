/*
 Elabora un algoritmo que permita leer el tamaño de un angulo en radianes e imprima la tangente, contangente
 secante y cosecante
 */
package ejercicio17;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner entrada=new Scanner(System.in);
// Declaracion de variables
double ta,cot,sec,cosec,rad;
// Solicitud de ingreso de datos
System.out.println("Ingrese los radianes");
rad=entrada.nextDouble();
//Calculos
rad=Math.toRadians(rad);
ta=Math.sin(rad)/Math.cos(rad);
cot=Math.cos(rad)/Math.sin(rad);
sec=1/Math.cos(rad);
cosec=1/Math.sin(rad);
//Muestra de datos en pantalla
System.out.println(" La tangente es "+ta+"\n La contangente es: "+cot+"\n La secante es "+sec+ "\n La cosecante es "+cosec);


    }
    
}
