/*
  Elabore un algoritmo que lea el articulo y su costo; la utilidad es el 150% y el impuesto es el 15%; 
  calcule e imprima artículo, utilidad, impuesto y precio de venta.
 */
package ejercicio9;
import  java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio9 {

    /**ro
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // decalaracion de varibles
       Scanner entrada = new Scanner(System.in);
       String nombPro ;
       double pre,utilidad,impuesto,preventa;
       // Solicitud de ingreso de valores
       System.out.println("Ingrese la descripcion del producto");
       nombPro=entrada.next();
       System.out.println("Ingrese el precio del producto ");
       pre=entrada.nextDouble();
       //Calculos
       utilidad=(pre*150)/100;
       impuesto=(pre*15)/100;
       preventa=(((pre*utilidad)+pre)*impuesto)+pre;
       //Muestra de datos en pantalla
       System.out.println("El nombre de su producto es: " +nombPro);
       System.out.println("Su utilidad es de: " +utilidad);
       System.out.println("El impusto es de: " +impuesto);
       System.out.println("El precio de venta es de: "+preventa);
               
       
       
       
       
       //
       
       
    }
    
}
